import time
async def response(gateway, command , msg , user_id, first_name, time_taken):
    text = f'''
<b>#Braintree_10</b><b>$ 🔥[</b><b>/btr</b><b>]
- - - - - - - - - - - - - - - - - - - - - - - -
[</b><a href="https://t.me/DROPXLIVE"><b>ϟ</b></a><b>]Card: </b><code>5237507521096048|04|2025|332</code><b> 
[</b><a href="https://t.me/DROPXLIVE"><b>ϟ</b></a><b>]Status: Declined ❌
[</b><a href="https://t.me/DROPXLIVE"><b>ϟ</b></a><b>]Result: Declined - Call Issuer
- - - - - - - - - - - - - - - - - - - - - - - -
[</b><a href="https://t.me/DROPXLIVE"><b>ϟ</b></a><b>]Bin info: </b><code>MASTERCARD</code><b> - </b><code>DEBIT</code><b> - </b><code>ENHANCED</code><b>
[</b><a href="https://t.me/DROPXLIVE"><b>ϟ</b></a><b>]Bank: </b><code>FISERV SOLUTIONS, LLC</code><b>
[</b><a href="https://t.me/DROPXLIVE"><b>ϟ</b></a><b>]Country: UNITED STATES [</b><code>🇺🇸</code><b>]
- - - - - - - - - - - - - - - - - - - - - - - -
[</b><a href="https://t.me/DROPXLIVE"><b>ϟ</b></a><b>]T/T: </b><code>8.02 Sec</code><b> | P: </b><code>Live ✅</code><b>
- - - - - - - - - - - - - - - - - - - - - - - -
[</b><a href="https://t.me/DROPXLIVE"><b>ϟ</b></a><b>]Req: </b><b>@XAY4N</b><b> [DEV]</b>
'''